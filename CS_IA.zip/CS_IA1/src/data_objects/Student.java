package data_objects;

public class Student extends Person{

	String year;
	String tutgroup;
	String house;
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getTutgroup() {
		return tutgroup;
	}
	public void setTutgroup(String tutgroup) {
		this.tutgroup = tutgroup;
	}
	public String getHouse() {
		return house;
	}
	public void setHouse(String house) {
		this.house = house;
	} 
	
	
	
}
